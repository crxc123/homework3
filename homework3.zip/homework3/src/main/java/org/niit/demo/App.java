package org.niit.demo;

import java.io.IOException;
import java.io.InputStream;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.niit.mapping.UserMapper;
import org.niit.pojo.User;

public class App {

	public static void main(String[] args) throws IOException {
		InputStream resource = Resources.getResourceAsStream("org/niit/config/myconfig.xml");
        SqlSessionFactory sessionFactory = new SqlSessionFactoryBuilder().build(resource);
        SqlSession session = sessionFactory.openSession();
        
        UserMapper userMapper = session.getMapper(UserMapper.class);
       // User user = userMapper.selectById(2);
       // System.out.println(user.toString());
        
        User user2=new User();
        user2.setPw("444");
        user2.setUsername("dd");
        userMapper.insertData(user2);
        session.commit();

	}

}
